/*******************************************************************************************
*
*   window.cpp
*   Not entirely sure what this will do, but as of now it manages windows. Hopefully.
*   Implements the header. Of course.
*
*******************************************************************************************/

#include "window.hpp"

Camera3D LonginusWindow::Viewport = {0};

Color LonginusWindow::VoidColour = BLACK;

bool LonginusWindow::Init(int width, int height, char* title) {

    InitWindow(width, height, title);
    InitAudioDevice();

    return IsWindowReady();    

}

bool LonginusWindow::ProcessFrame() {

    /*Rendering starts here. Draw UI and other crap here. Or else shit will break unimmaginably.*/
    BeginDrawing();
    ClearBackground(LonginusWindow::VoidColour);

    /*Rendering of 3D objects starts here. Draw 3D stuff here. Or else, you can guess what will happen.*/
    BeginMode3D(LonginusWindow::Viewport);

    /*Rendering stops here. It draws over empty space with .*/
    EndMode3D();
    EndDrawing();
}